 /*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * @defgroup main MAIN
 * 
 * @brief This is the generated driver implementation file for the MAIN driver.
 *
 * @version MAIN Driver Version 1.0.2
 *
 * @version Package Version: 3.1.2
*/

/*
� [2026] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/
#include "mcc_generated_files/system/system.h"
#include "stdio.h"
#include "string.h"

//Timer & Communication Setup
float time_ms;
float tenths;
float distime;
float seconds;
float time_down;
float time_error;
float time_success;
float time_rollcall;
float receive_start;
int i = 0;
int j = 0;
uint8_t byte;
uint8_t tempbyte;
uint8_t distance;
uint8_t prefix[2] = {'A','Z'};
uint8_t suffix[2] = {'Y','B'};
uint8_t receiveBuffer[60];
uint8_t sendBuffer[4];
bool check1 = false;
bool last_state = true;

void TimerCallback(void);
void SendDistance(uint8_t data);
void RollCall(void);
void ReceiveMessage(void);
void ReactMessage(void);

//LiDAR setup

#define TFLUNA_ADDRESS 0x10

#define TFL_DIST_LO 0x00
#define TFL_DIST_HI 0x01
#define TFL_TRG_MODE 0x23
#define TFL_TRIGGER 0x24
#define TFL_DISABLE 0x25
#define TFL_SOFTRESET 0x21
#define TFL_HARDRESET 0x29

uint16_t distance_og;

void ContinuousMode(void);
void TriggerMode(void);
uint16_t TriggerDistance(void);
uint16_t ReadDistance(void);
uint16_t FrameRead(void);
void SoftReset(void);
void HardReset(void);
void TFLunaEnable(void);
void WriteFPS(void);
void ReadFPS(void);

/*
    Main application
*/

int main(void)
{
    SYSTEM_Initialize();
    I2C1_Initialize();
    
    __delay_ms(1000);
    
    INTERRUPT_GlobalInterruptEnable(); 
    //INTERRUPT_GlobalInterruptDisable(); 

    TMR0_PeriodMatchCallbackRegister(TimerCallback);
    TMR0_Start();

    while(1)
    {
        //Button debouncing
        bool pin_state = PUSH_BUTTON_GetValue();
        if(pin_state != last_state){
            time_down = time_ms;
        }
        if((time_ms - time_down >= 50)&&(time_ms - time_rollcall >= 5000)){
            if(pin_state == 0){
                RollCall(); //Send roll call broadcast message if button pushed
                time_rollcall = time_ms;
            }
        }
        last_state = pin_state;
        
        if(tenths >= 100){ //Scan for received messages every 100 ms
        tenths -= 100;
        ReceiveMessage(); 
        }
        
        if(distime >= 100){ //Read distance every 100 ms
            distime -= 100;
            distance_og = ReadDistance();
        }
        
        if(distance_og >= 800){ //Filter out unreliable distance data (over 8 meters)
            distance = 800;
        }
        else{
            distance = distance_og;
        }
        
        //Turns message status LEDs off after one second
        if(time_ms - time_error > 1000){
            LED_RED_SetLow();
        }
        if(time_ms - time_success > 1000){
            LED_GREEN_SetLow();
        }
    }    
}

void TimerCallback(void){ //Timer interrupt function
    time_ms++; //One millisecond
    tenths++;  //100 milliseconds
    distime++;  //100 milliseconds
    seconds++; //One second
    
    if(seconds >= 2000){    //Send distance data every two seconds
        seconds -= 2000;
        SendDistance(distance);
    }
    
}

//Communication Functions

void SendDistance(uint8_t data){    //Function to send distance data
    printf("AZJAF%uYB", data);
}

void RollCall(void){                //Function to send roll call broadcast
    printf("AZJXLYB");
}

void ReceiveMessage(void){          //Function to receive bytes from UART chain and react accordingly
    i = 0;
    j = 0;
    check1 = 0;
    memset(receiveBuffer, 0, sizeof(receiveBuffer));    //Clears message buffer
    receive_start = time_ms;
    while(1){
        if(time_ms - receive_start > 200){              //Leaves function if message not finished after 200 ms
            return;
        }
        if(UART1_IsRxReady()){
            byte = UART1_Read();                        //Reads one byte from UART
            j++;
            if((check1 == 0)&&(j>64)){                  //Leaves function if message prefix not received after 64 bytes
                //printf("\r\nError: Prefix never received!!!\r\n");
                time_error = time_ms;
                LED_RED_SetHigh();
                return;
            }
            else if(i>59){                              //Leaves function if message content > 59 bytes
                //printf("\r\nError: Message too long!!!\r\n");
                LED_RED_SetHigh();
                time_error = time_ms;
                return;
            }
            else if((byte == prefix[0])&&(check1 == 0)){    //Checks for message prefix if not yet received
                while(UART1_IsRxReady() == 0);
                byte = UART1_Read();
                j++;
                if(byte == prefix[1]){
                    check1 = 1;
                }
                else if(byte == prefix[0]){
                    while(UART1_IsRxReady() == 0);
                    byte = UART1_Read();
                    j++;
                    if(byte == prefix[1]){
                        check1 = 1;
                    }
                }
                else{
                }
            }
            else if((check1 == 1)&&(i <= 59)&&(byte != suffix[0])){ //If prefix has been received, stores byte in buffer
                receiveBuffer[i] = byte;
                i++;
            }
            else if((check1 == 1)&&(byte == suffix[0])){    //Checks for message suffix
                tempbyte = byte;
                while(UART1_IsRxReady() == 0);
                byte = UART1_Read();
                j++;
                if(byte == suffix[1]){
                    ReactMessage();                 //If suffix is received, calls function to react to message
                    return;
                }
                else if(byte == suffix[0]){
                    receiveBuffer[i] = tempbyte;
                    i++;
                    tempbyte = byte;
                    while(UART1_IsRxReady() == 0);
                    byte = UART1_Read();
                    j++;
                    if(byte == suffix[1]){
                        ReactMessage();
                        return;
                    }
                    else{
                        //printf("\r\nError: Three 'Y's in a row is evil!!!\r\n");
                        LED_RED_SetHigh();
                        time_error = time_ms;
                        return;
                    }
                }
                else{                           //If suffix is not complete, stores bytes as message content
                    receiveBuffer[i] = tempbyte;
                    i++;
                    receiveBuffer[i] = byte;
                    i++;
                }
            }
            else{
            }
        }
    }
}

void ReactMessage(void){    //Function to react to received message
    if((receiveBuffer[0] < 'A')||(receiveBuffer[0] > 'J')){     //If sender ID not valid, trash message
        //printf("\r\nError: Sender ID not recognized!!!\r\n");
        LED_RED_SetHigh();
        time_error = time_ms;
        return;
    }
    else if(((receiveBuffer[1] < 'A')||(receiveBuffer[1] > 'J'))&&(receiveBuffer[1] != 'X')){   //If receiver ID not valid, trash message
        //printf("\r\nError: Receiver ID not recognized!!!\r\n");
        LED_RED_SetHigh();
        time_error = time_ms;
        return;
    }
    else if(receiveBuffer[1]=='X'){
        if(receiveBuffer[0]=='J'){      //If broadcast message from self, act upon and trash message
            //printf("\r\nThis was a broadcast message sent from self: noted and trashed.\n\r");
            return;
        }
        else{       //If broadcast message from teammate, act upon/pass along
            //printf("\r\nBroadcast message noted/acted upon and passed along:\n\r");
            printf("AZ");
            for(int z=0; z<i; z++){
                printf("%c", receiveBuffer[z]);
            }
            printf("YB");
            LED_GREEN_SetHigh();
            time_success = time_ms;
            return;
        }
    }
    else if(receiveBuffer[0]=='J'){     //If message from self, trash
        //printf("\r\nMessage is from self: message trashed.\r\n");
        return;
    }
    else if(receiveBuffer[1]=='J'){     //If message meant for me, act upon and trash
        //printf("\r\nThe following message is meant for me:\r\n");
        //for(int x=0; x<i; x++){
        //    printf("%c", receiveBuffer[x]);
        //}
        //printf("\r\n");
        LED_GREEN_SetHigh();
        time_success = time_ms;
        return;
    }
    else{       //If message from valid teammate to valid teammate, pass along
        printf("AZ");
        for(int y=0; y<i; y++){
            printf("%c", receiveBuffer[y]);
        }
        printf("YB");
        LED_GREEN_SetHigh();
        time_success = time_ms;
        return;
        }
}

//LiDAR Functions

void ContinuousMode(void){
    uint8_t cmd[2] = {TFL_TRG_MODE, 0};
    I2C1_Host.Write(TFLUNA_ADDRESS, cmd, 2);
    while (I2C1_IsBusy());
}

void TriggerMode(void){
    uint8_t cmd[2] = {TFL_TRG_MODE, 1};
    I2C1_Host.Write(TFLUNA_ADDRESS, cmd, 2);
    while (I2C1_IsBusy());
}

uint16_t TriggerDistance(void)
{
    uint8_t lo;
    uint8_t hi;
    uint8_t reg;
    
    uint8_t cmd[2] = {TFL_TRIGGER, 1};
    I2C1_Host.Write(TFLUNA_ADDRESS, cmd, 2);
    while (I2C1_IsBusy());
    
    __delay_ms(100);
    
    reg = TFL_DIST_LO;
    I2C1_Host.WriteRead(TFLUNA_ADDRESS, &reg, 1, &lo, 1);
    while (I2C1_IsBusy());

    reg = TFL_DIST_HI;
    I2C1_Host.WriteRead(TFLUNA_ADDRESS, &reg, 1, &hi, 1);
    while (I2C1_IsBusy());

    return ((uint16_t)hi << 8) | lo;
}

uint16_t ReadDistance(void)
{
    uint8_t lo;
    uint8_t hi;
    uint8_t reg;
    
    if(DATA_READY_GetValue() != 1){
        //printf("Value not ready\r\n");
        return distance;
    }
    
    reg = TFL_DIST_LO;
    I2C1_Host.WriteRead(TFLUNA_ADDRESS, &reg, 1, &lo, 1);
    while (I2C1_IsBusy());

    reg = TFL_DIST_HI;
    I2C1_Host.WriteRead(TFLUNA_ADDRESS, &reg, 1, &hi, 1);
    while (I2C1_IsBusy());

    return ((uint16_t)hi << 8) | lo;
}

uint16_t FrameRead(void){
    
    static uint8_t frame[9];
    static uint8_t dummy = 0x00;

    I2C1_Host.WriteRead(TFLUNA_ADDRESS, &dummy, 1, frame, 9);
    while (I2C1_IsBusy());
    
    printf("%02X %02X %02X %02X %02X %02X %02X %02X %02X\r\n", frame[0], frame[1], frame[2], frame[3], frame[4], frame[5], frame[6], frame[7], frame[8]);

    if (frame[0] == 0x59 && frame[1] == 0x59){
        distance = ((uint16_t)frame[3] << 8) | frame[2];
    }
    
    return distance;
}

void SoftReset(void){
    uint8_t cmd[2] = {TFL_SOFTRESET, 0x02};
    I2C1_Host.Write(TFLUNA_ADDRESS, cmd, 2);
    while (I2C1_IsBusy());
    __delay_ms(3000);
}

void HardReset(void){
    uint8_t cmd[2] = {TFL_HARDRESET, 1};
    I2C1_Host.Write(TFLUNA_ADDRESS, cmd, 2);
    while (I2C1_IsBusy());
    __delay_ms(3000);
}

void TFLunaEnable(void){
    uint8_t cmd[2] = {TFL_DISABLE, 1};
    I2C1_Host.Write(TFLUNA_ADDRESS, cmd, 2);
    while (I2C1_IsBusy());
    __delay_ms(100);
}

void WriteFPS(void){
    uint8_t cmd[2] = {0x26, 0x64};
    I2C1_Host.Write(TFLUNA_ADDRESS, cmd, 2);
    while(I2C1_IsBusy());
}

void ReadFPS(void){
    uint8_t fps;
    uint8_t reg = 0x26;

    I2C1_Host.WriteRead(TFLUNA_ADDRESS, &reg, 1, &fps, 1);
    while(I2C1_IsBusy());

    printf("FPS readback: %02X\r\n", fps);
}